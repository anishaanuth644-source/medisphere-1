// src/firebase/config.js
// Initializes Firebase. Fails gracefully when env vars are missing
// so the app shows a setup screen instead of a blank white page.

import { initializeApp, getApps } from "firebase/app";
import { getAuth, setPersistence, browserLocalPersistence } from "firebase/auth";
import { getFirestore, connectFirestoreEmulator } from "firebase/firestore";
import { getStorage, connectStorageEmulator } from "firebase/storage";

const {
  VITE_FIREBASE_API_KEY: apiKey,
  VITE_FIREBASE_AUTH_DOMAIN: authDomain,
  VITE_FIREBASE_PROJECT_ID: projectId,
  VITE_FIREBASE_STORAGE_BUCKET: storageBucket,
  VITE_FIREBASE_MESSAGING_SENDER_ID: messagingSenderId,
  VITE_FIREBASE_APP_ID: appId,
  VITE_USE_FIREBASE_EMULATORS: useEmulators,
} = import.meta.env;

// Export a flag so UI can show a "configure Firebase" screen
export const FIREBASE_CONFIGURED =
  !!apiKey && !!authDomain && !!projectId && !!appId;

const firebaseConfig = {
  apiKey: apiKey || "MISSING",
  authDomain: authDomain || "MISSING",
  projectId: projectId || "MISSING",
  storageBucket: storageBucket || "MISSING",
  messagingSenderId: messagingSenderId || "MISSING",
  appId: appId || "MISSING",
};

let app, auth, db, storage;

try {
  app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);
  storage = getStorage(app);

  // Only set persistence when properly configured
  if (FIREBASE_CONFIGURED) {
    setPersistence(auth, browserLocalPersistence).catch((err) => {
      console.warn("[MediSphere] Auth persistence error:", err.message);
    });
  }

  if (useEmulators === "true" && FIREBASE_CONFIGURED) {
    connectFirestoreEmulator(db, "localhost", 8080);
    connectStorageEmulator(storage, "localhost", 9199);
    console.info("[MediSphere] Using Firebase emulators");
  }
} catch (err) {
  console.error("[MediSphere] Firebase init error:", err.message);
}

export { app, auth, db, storage };
