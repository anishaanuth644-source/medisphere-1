// src/context/AuthContext.jsx
import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  sendPasswordResetEmail,
} from "firebase/auth";
import { doc, getDoc, updateDoc, serverTimestamp } from "firebase/firestore";
import { auth, db, FIREBASE_CONFIGURED } from "../firebase/config";
import { logAuditEvent } from "../services/auditService";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [firebaseUser, setFirebaseUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [authError, setAuthError] = useState(null);

  useEffect(() => {
    // If Firebase is not configured, stop loading immediately
    if (!FIREBASE_CONFIGURED) {
      setLoading(false);
      return;
    }

    let unsubscribe = () => {};
    try {
      unsubscribe = onAuthStateChanged(auth, async (user) => {
        setFirebaseUser(user);
        if (user) {
          try {
            const snap = await getDoc(doc(db, "users", user.uid));
            if (snap.exists()) {
              const data = snap.data();
              if (!data.active) {
                await firebaseSignOut(auth);
                setProfile(null);
                setAuthError("This account has been deactivated. Contact your administrator.");
              } else {
                setProfile({ uid: user.uid, ...data });
                updateDoc(doc(db, "users", user.uid), {
                  lastLoginAt: serverTimestamp(),
                }).catch(() => {});
              }
            } else {
              setProfile(null);
              setAuthError("No role configured for this account. Ask a Super Admin to provision your profile.");
            }
          } catch (err) {
            console.error("Profile load error:", err);
            setAuthError("Could not load your profile. Check your connection.");
          }
        } else {
          setProfile(null);
        }
        setLoading(false);
      });
    } catch (err) {
      console.error("Auth listener error:", err);
      setLoading(false);
    }
    return unsubscribe;
  }, []);

  const login = useCallback(async (email, password) => {
    setAuthError(null);
    if (!FIREBASE_CONFIGURED) {
      return { success: false, message: "Firebase is not configured. See setup instructions." };
    }
    try {
      const cred = await signInWithEmailAndPassword(auth, email, password);
      await logAuditEvent({ action: "login", userId: cred.user.uid }).catch(() => {});
      return { success: true };
    } catch (err) {
      const message = mapAuthError(err.code);
      setAuthError(message);
      return { success: false, message };
    }
  }, []);

  const logout = useCallback(async () => {
    if (firebaseUser) {
      await logAuditEvent({ action: "logout", userId: firebaseUser.uid }).catch(() => {});
    }
    if (FIREBASE_CONFIGURED) {
      await firebaseSignOut(auth).catch(() => {});
    }
  }, [firebaseUser]);

  const resetPassword = useCallback(async (email) => {
    if (!FIREBASE_CONFIGURED) {
      return { success: false, message: "Firebase is not configured." };
    }
    try {
      await sendPasswordResetEmail(auth, email);
      return { success: true };
    } catch (err) {
      return { success: false, message: mapAuthError(err.code) };
    }
  }, []);

  const value = {
    firebaseUser,
    profile,
    role: profile?.role || null,
    isAuthenticated: !!firebaseUser && !!profile,
    loading,
    authError,
    firebaseConfigured: FIREBASE_CONFIGURED,
    login,
    logout,
    resetPassword,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}

function mapAuthError(code) {
  const map = {
    "auth/invalid-email": "That email address looks invalid.",
    "auth/user-disabled": "This account has been disabled.",
    "auth/user-not-found": "Incorrect email or password.",
    "auth/wrong-password": "Incorrect email or password.",
    "auth/invalid-credential": "Incorrect email or password.",
    "auth/too-many-requests": "Too many attempts. Wait a few minutes and try again.",
  };
  return map[code] || "Sign-in failed. Please try again.";
}
