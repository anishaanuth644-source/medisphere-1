// src/services/auditService.js
// Append-only audit log writer. Never throws — audit failure must not
// crash the feature that triggered it.
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { db, FIREBASE_CONFIGURED } from "../firebase/config";

export async function logAuditEvent({
  action,
  userId = "system",
  userName = "",
  targetCollection = null,
  targetDocId = null,
  metadata = null,
}) {
  if (!FIREBASE_CONFIGURED || !db) return;
  try {
    await addDoc(collection(db, "audit_logs"), {
      action,
      userId,
      userName,
      targetCollection,
      targetDocId,
      metadata,
      ipAddress: null,
      createdAt: serverTimestamp(),
    });
  } catch (err) {
    console.warn("[Audit] Failed to write log:", err.message);
  }
}
