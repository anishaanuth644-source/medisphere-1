// src/services/patientService.js
import {
  collection, doc, setDoc, getDoc, getDocs,
  updateDoc, query, orderBy, limit, serverTimestamp,
} from "firebase/firestore";
import { db } from "../firebase/config";
import { logAuditEvent } from "./auditService";
import { generatePatientId } from "../utils/idGenerators";

const COL = "patients";

export async function getPatient(patientId) {
  const snap = await getDoc(doc(db, COL, patientId));
  return snap.exists() ? { id: snap.id, ...snap.data() } : null;
}

export async function getAllPatients({ limitCount = 200 } = {}) {
  const q = query(collection(db, COL), orderBy("createdAt", "desc"), limit(limitCount));
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
}

export async function searchPatients(searchTerm) {
  const all = await getAllPatients({ limitCount: 500 });
  const term = searchTerm.toLowerCase();
  return all.filter(
    (p) =>
      p.name?.toLowerCase().includes(term) ||
      p.id?.toLowerCase().includes(term) ||
      p.phone?.includes(term)
  );
}

export async function registerPatient(data, actingUser) {
  const patientId = generatePatientId();
  const payload = {
    ...data,
    patientId,
    qrCodeValue: patientId,
    registeredAt: serverTimestamp(),
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
    createdBy: actingUser.uid,
  };
  await setDoc(doc(db, COL, patientId), payload);
  await logAuditEvent({
    action: "patient_registered",
    userId: actingUser.uid,
    userName: actingUser.displayName || "",
    targetCollection: COL,
    targetDocId: patientId,
  });
  return patientId;
}

export async function updatePatient(patientId, updates, actingUser) {
  await updateDoc(doc(db, COL, patientId), {
    ...updates,
    updatedAt: serverTimestamp(),
  });
  await logAuditEvent({
    action: "patient_record_update",
    userId: actingUser.uid,
    userName: actingUser.displayName || "",
    targetCollection: COL,
    targetDocId: patientId,
    metadata: { updatedFields: Object.keys(updates) },
  });
}

export async function deactivatePatient(patientId, actingUser) {
  await updatePatient(patientId, { active: false }, actingUser);
}
