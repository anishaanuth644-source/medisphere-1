// src/components/SetupScreen.jsx
// Shown when VITE_FIREBASE_* env vars are missing.
// Gives the user clear instructions instead of a white page.
import React from "react";

export function SetupScreen() {
  return (
    <div style={{
      minHeight: "100vh", display: "flex", alignItems: "center",
      justifyContent: "center", background: "linear-gradient(135deg,#f0f9ff,#ecfdf5)",
      padding: "24px", fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
    }}>
      <div style={{ maxWidth: 540, width: "100%" }}>
        {/* Logo */}
        <div style={{ textAlign: "center", marginBottom: 28 }}>
          <div style={{
            width: 56, height: 56, borderRadius: 18,
            background: "linear-gradient(135deg,#0ea5e9,#0d9488)",
            display: "inline-flex", alignItems: "center", justifyContent: "center",
            fontSize: 26, marginBottom: 12, boxShadow: "0 8px 24px rgba(14,165,233,0.3)",
          }}>❤️</div>
          <div style={{ fontSize: 22, fontWeight: 700, color: "#1e293b" }}>MediSphere</div>
          <div style={{ fontSize: 13, color: "#64748b", marginTop: 4 }}>
            Smart Digital Hospital Ecosystem
          </div>
        </div>

        {/* Card */}
        <div style={{
          background: "rgba(255,255,255,0.9)", backdropFilter: "blur(20px)",
          borderRadius: 22, padding: 32, border: "1px solid rgba(14,165,233,0.15)",
          boxShadow: "0 20px 60px rgba(14,165,233,0.12)",
        }}>
          <div style={{
            display: "flex", alignItems: "center", gap: 10, marginBottom: 16,
            padding: "12px 16px", borderRadius: 12,
            background: "rgba(245,158,11,0.08)", border: "1px solid rgba(245,158,11,0.25)",
          }}>
            <span style={{ fontSize: 18 }}>⚙️</span>
            <div>
              <div style={{ fontSize: 13, fontWeight: 600, color: "#b45309" }}>
                Firebase configuration required
              </div>
              <div style={{ fontSize: 11.5, color: "#92400e", marginTop: 2 }}>
                Environment variables are not set. Follow the steps below.
              </div>
            </div>
          </div>

          <div style={{ fontSize: 13, fontWeight: 600, color: "#334155", marginBottom: 12 }}>
            Setup steps:
          </div>

          {[
            {
              n: 1,
              title: "Create a Firebase project",
              body: "Go to console.firebase.google.com → Add project → Enable Authentication (Email/Password), Firestore, and Storage.",
            },
            {
              n: 2,
              title: "Copy the environment file",
              body: "In your project root: cp .env.example .env.local",
              code: "cp .env.example .env.local",
            },
            {
              n: 3,
              title: "Add your Firebase credentials",
              body: "Open .env.local and paste your web app config from Firebase Console → Project settings → General → Your apps.",
            },
            {
              n: 4,
              title: "Deploy security rules & seed data",
              body: "",
              code: "firebase deploy --only firestore:rules,firestore:indexes,storage\nnode scripts/seedFirestore.js",
            },
            {
              n: 5,
              title: "Restart the dev server",
              body: "",
              code: "npm run dev",
            },
          ].map((step) => (
            <div key={step.n} style={{ display: "flex", gap: 12, marginBottom: 16 }}>
              <div style={{
                width: 24, height: 24, borderRadius: "50%", flexShrink: 0,
                background: "linear-gradient(135deg,#0ea5e9,#0d9488)",
                color: "#fff", fontSize: 11, fontWeight: 700,
                display: "flex", alignItems: "center", justifyContent: "center",
                marginTop: 1,
              }}>
                {step.n}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: "#1e293b", marginBottom: 3 }}>
                  {step.title}
                </div>
                {step.body && (
                  <div style={{ fontSize: 12, color: "#64748b", lineHeight: 1.5 }}>
                    {step.body}
                  </div>
                )}
                {step.code && (
                  <pre style={{
                    marginTop: 6, fontSize: 11.5, background: "#1e293b", color: "#7dd3fc",
                    padding: "8px 12px", borderRadius: 8, overflow: "auto",
                    fontFamily: "'Fira Code', monospace", lineHeight: 1.6,
                  }}>
                    {step.code}
                  </pre>
                )}
              </div>
            </div>
          ))}

          <div style={{
            marginTop: 8, padding: "12px 16px", borderRadius: 12,
            background: "#f0f9ff", border: "1px solid rgba(14,165,233,0.2)",
            fontSize: 12, color: "#0369a1", lineHeight: 1.6,
          }}>
            📄 See <strong>README.md</strong> in the project root for the complete setup guide
            including Firebase Console screenshots and Firestore schema documentation.
          </div>
        </div>
      </div>
    </div>
  );
}
