// src/components/ErrorBoundary.jsx
// Catches any runtime React errors and shows a friendly screen
// instead of a blank white page.
import React from "react";

export class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, info) {
    console.error("[MediSphere] Runtime error:", error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{
          minHeight: "100vh", display: "flex", alignItems: "center",
          justifyContent: "center", background: "linear-gradient(135deg,#f0f9ff,#ecfdf5)",
          padding: "24px", fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
        }}>
          <div style={{
            maxWidth: 480, background: "rgba(255,255,255,0.9)", borderRadius: 20,
            padding: 32, border: "1px solid rgba(14,165,233,0.15)",
            boxShadow: "0 20px 60px rgba(14,165,233,0.12)",
          }}>
            <div style={{ fontSize: 32, marginBottom: 12 }}>⚠️</div>
            <h2 style={{ fontSize: 20, fontWeight: 700, color: "#1e293b", marginBottom: 8 }}>
              Something went wrong
            </h2>
            <p style={{ fontSize: 13, color: "#64748b", marginBottom: 16, lineHeight: 1.6 }}>
              MediSphere encountered an error. This is most likely because Firebase environment
              variables are not configured. Please check your <code style={{
                background: "#f1f5f9", padding: "2px 6px", borderRadius: 4, fontSize: 12,
              }}>.env.local</code> file.
            </p>
            <details style={{ marginBottom: 20 }}>
              <summary style={{ fontSize: 12, color: "#94a3b8", cursor: "pointer" }}>
                Technical details
              </summary>
              <pre style={{
                marginTop: 8, fontSize: 11, color: "#ef4444", background: "#fff1f2",
                padding: 10, borderRadius: 8, overflow: "auto", lineHeight: 1.5,
              }}>
                {this.state.error?.message || "Unknown error"}
              </pre>
            </details>
            <div style={{
              background: "#f0f9ff", borderRadius: 12, padding: 16,
              border: "1px solid rgba(14,165,233,0.2)", marginBottom: 16,
            }}>
              <p style={{ fontSize: 12, fontWeight: 600, color: "#0369a1", marginBottom: 8 }}>
                Quick fix:
              </p>
              <ol style={{ fontSize: 12, color: "#475569", paddingLeft: 16, lineHeight: 1.8 }}>
                <li>Copy <code>.env.example</code> to <code>.env.local</code></li>
                <li>Fill in your Firebase project credentials</li>
                <li>Run <code>npm run dev</code> again</li>
              </ol>
            </div>
            <button
              onClick={() => window.location.reload()}
              style={{
                width: "100%", padding: "11px 0", borderRadius: 12, border: "none",
                background: "linear-gradient(135deg,#0ea5e9,#0d9488)", color: "#fff",
                fontSize: 13, fontWeight: 600, cursor: "pointer",
              }}
            >
              Reload page
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
